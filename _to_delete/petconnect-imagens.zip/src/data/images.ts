// Ilustrações originais dos animais e das ONGs (assets/animais e assets/ong).
// O Metro exige caminhos fixos em require(), por isso o mapa é escrito por extenso.
import type { ImageSourcePropType } from 'react-native';

/** Fotos de cada animal; a primeira é a principal (cards e listas). */
export const petPhotos: Record<string, ImageSourcePropType[]> = {
  skye: [
    require('../../assets/animais/skye.png'),
    require('../../assets/animais/skye-2.png'),
    require('../../assets/animais/skye-3.png'),
    require('../../assets/animais/skye-4.png'),
  ],
  lua: [
    require('../../assets/animais/lua.png'),
    require('../../assets/animais/lua-2.png'),
    require('../../assets/animais/lua-3.png'),
    require('../../assets/animais/lua-4.png'),
  ],
  thor: [
    require('../../assets/animais/thor.png'),
    require('../../assets/animais/thor-2.png'),
    require('../../assets/animais/thor-3.png'),
    require('../../assets/animais/thor-4.png'),
  ],
  nina: [
    require('../../assets/animais/nina.png'),
    require('../../assets/animais/nina-2.png'),
    require('../../assets/animais/nina-3.png'),
    require('../../assets/animais/nina-4.png'),
  ],
  bob: [require('../../assets/animais/bob.png')],
  mel: [require('../../assets/animais/mel.png')],
  pipoca: [require('../../assets/animais/pipoca.png')],
  rex: [require('../../assets/animais/rex.png')],
  tigre: [require('../../assets/animais/tigre.png')],
  amora: [require('../../assets/animais/amora.png')],
  mingau: [require('../../assets/animais/mingau.png')],
  faisca: [require('../../assets/animais/faisca.png')],
  pretinha: [require('../../assets/animais/pretinha.png')],
  biscoito: [require('../../assets/animais/biscoito.png')],
};

/** Logo de cada ONG. */
export const ongLogos: Record<string, ImageSourcePropType> = {
  abc: require('../../assets/ongs/abc.png'),
  patas: require('../../assets/ongs/patas.png'),
  lar: require('../../assets/ongs/lar.png'),
};

/** Foto principal do animal, ou `undefined` quando não houver (a tela mostra o bloco cinza). */
export const petPhoto = (id: string | undefined): ImageSourcePropType | undefined =>
  id ? petPhotos[id]?.[0] : undefined;
